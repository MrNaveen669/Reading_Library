// Location.js
import React from "react";

const locations = [
  {
    id: 1,
    name: "New York",
    iframeSrc: "https://www.google.com/maps/place/Apollo+24%2F7+Lab+Test+Near+Me+%7C+Rohnipuram+%7C+Raipur/@21.2367173,81.6010415,20.39z/data=!4m6!3m5!1s0x3a28df0996050c2b:0x2325a4124dc51408!8m2!3d21.2366361!4d81.6011592!16s%2Fg%2F11w3l5vhcq?hl=en&entry=ttu&g_ep=EgoyMDI0MTIxMS4wIKXMDSoASAFQAw%3D%3D",
  },
  {
    id: 2,
    name: "Los Angeles",
    iframeSrc: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d423286.2742582128!2d-118.69193042518849!3d34.02016130719765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2z0YDRgdC60LXRgtCw0L3QvtCz0L4g!5e0!3m2!1sen!2sus!4v1616331860934!5m2!1sen!2sus",
  },
  {
    id: 3,
    name: "Chicago",
    iframeSrc: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d38112.73991403864!2d-87.74408449537727!3d41.87807842170078!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2z0YHQtdGC0LXQuNC90L7Qs9Cw0YbQuNC-!5e0!3m2!1sen!2sus!4v1616331941887!5m2!1sen!2sus",
  },
];

const Location = () => {
  return (
    <div style={{ margin: "20px", padding: "20px", textAlign: "center" }}>
      <h2>Our Locations</h2>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px", justifyContent: "center" }}>
        {locations.map((location) => (
          <div key={location.id} style={{ width: "300px", height: "300px" }}>
            <h3>{location.name}</h3>
            <iframe
              src={location.iframeSrc}
              width="100%"
              height="250"
              style={{ border: "0" }}
              allowFullScreen=""
              loading="lazy"
              title={location.name}
            ></iframe>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Location;
