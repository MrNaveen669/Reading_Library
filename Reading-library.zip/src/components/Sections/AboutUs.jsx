import React from "react";
import styled from "styled-components";
import ProfilePhoto1 from "../../assets/img/profile3.jpg";
import ProfilePhoto2 from "../../assets/img/profile2.png";

const AboutUsSection = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #f5f5f5;
  padding: 40px 20px;
`;

const ProfileWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  width: 100%;
  max-width: 1200px;
  margin-bottom: 40px;
`;

const ProfileLeft = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`;

const ProfileImageWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
  img {
    width: 150px;
    height: 150px;
    object-fit: cover;
    border-radius: 8px;
  }
`;

const ProfileRight = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`;

const Divider = styled.hr`
  width: 100%;
  max-width: 1200px;
  border: 0;
  height: 1px;
  background-color: #ccc;
  margin: 20px 0;
`;

const ButtonsRow = styled.div`
  display: flex;
  align-items: center;
`;

const FullButton = ({ title, action, border }) => (
  <button
    onClick={action}
    style={{
      width: "100%",
      padding: "10px 20px",
      border: border ? "2px solid black" : "none",
      background: border ? "transparent" : "black",
      color: border ? "black" : "white",
      cursor: "pointer",
      borderRadius: "5px",
    }}
  >
    {title}
  </button>
);

const AboutUs = () => (
  <AboutUsSection>
    <ProfileWrapper>
      <ProfileLeft>
        <ProfileImageWrapper>
          <img className="radius8" src={ProfilePhoto1} alt="Profile 1" />
        </ProfileImageWrapper>
        <h4 className="font15 semiBold">About Us</h4>
        <h2 className="font40 extraBold">Your Company Name</h2>
        <p className="font12">
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed
          diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        </p>
        <p className="font12">
          <strong>Phone:</strong> +1 234 567 8900
        </p>
        <p className="font12">
          <strong>Email:</strong> info@yourcompany.com
        </p>
        <ButtonsRow style={{ margin: "30px 0" }}>
          <div style={{ width: "190px" }}>
            <FullButton title="Learn More" action={() => alert("Learn More clicked")} />
          </div>
          <div style={{ width: "190px", marginLeft: "15px" }}>
            <FullButton title="Contact Us" action={() => alert("Contact Us clicked")} border />
          </div>
        </ButtonsRow>
      </ProfileLeft>
      <ProfileRight>
        <ProfileImageWrapper>
          <img className="radius8" src={ProfilePhoto2} alt="Profile 2" />
        </ProfileImageWrapper>
        <h4 className="font15 semiBold">Team Member</h4>
        <h2 className="font40 extraBold">John Doe</h2>
        <p className="font12">
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed
          diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        </p>
        <p className="font12">
          <strong>Phone:</strong> +1 987 654 3210
        </p>
        <p className="font12">
          <strong>Email:</strong> johndoe@yourcompany.com
        </p>
        <ButtonsRow style={{ margin: "30px 0" }}>
          <div style={{ width: "190px" }}>
            <FullButton title="View Profile" action={() => alert("View Profile clicked")} />
          </div>
          <div style={{ width: "190px", marginLeft: "15px" }}>
            <FullButton title="Contact" action={() => alert("Contact clicked")} border />
          </div>
        </ButtonsRow>
      </ProfileRight>
    </ProfileWrapper>
    <Divider />
  </AboutUsSection>
);

export default AboutUs;
