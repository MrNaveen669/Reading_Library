import React from "react";
import styled from "styled-components";

export default function Contact() {
  return (
    <Wrapper id="contact">
      <Background>
        <div className="container">
          <HeaderInfo>
            <h1 className="font40 extraBold">Let’s get in touch</h1>
            <p className="font13">
              We would love to hear from you! Please fill out the form below, and we will get back to you as soon as possible.
            </p>
          </HeaderInfo>
          <Card>
            <FormWrapper>
              <Form>
                <label className="font13">First Name:</label>
                <Input type="text" id="fname" name="fname" placeholder="Enter your first name" />

                <label className="font13">Email:</label>
                <Input type="email" id="email" name="email" placeholder="Enter your email" />

                <label className="font13">Subject:</label>
                <Input type="text" id="subject" name="subject" placeholder="Enter the subject" />

                <label className="font13">Message:</label>
                <Textarea rows="4" id="message" name="message" placeholder="Write your message here" />
              </Form>
              <SubmitWrapper>
                <ButtonInput type="submit" value="Send Message" />
              </SubmitWrapper>
            </FormWrapper>
          </Card>
        </div>
      </Background>
    </Wrapper>
  );
}

const Wrapper = styled.section`
  width: 100%;
  padding: 50px 0;
  background-color: #ffffff;
`;

const Background = styled.div`
  background: #f0f0f0;
  padding: 50px;
  border-radius: 12px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
`;

const HeaderInfo = styled.div`
  text-align: center;
  color: #333;
  padding-bottom: 30px;

  h1 {
    font-size: 36px;
    font-weight: 700;
    margin-bottom: 15px;
  }

  p {
    font-size: 16px;
    line-height: 1.6;
    max-width: 600px;
    margin: 0 auto;
  }
`;

const Card = styled.div`
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  padding: 40px;
  max-width: 600px;
  margin: 0 auto;
`;

const FormWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;

const Form = styled.form`
  width: 100%;
  label {
    display: block;
    color: #333;
    margin-bottom: 8px;
    font-size: 14px;
  }
`;

const Input = styled.input`
  width: 100%;
  padding: 12px 15px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background: #fff;
  font-size: 16px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  :focus {
    outline: none;
    border-color: #6a11cb;
    box-shadow: 0 0 8px rgba(106, 17, 203, 0.5);
  }
`;

const Textarea = styled.textarea`
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background: #fff;
  font-size: 16px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  resize: none;

  :focus {
    outline: none;
    border-color: #6a11cb;
    box-shadow: 0 0 8px rgba(106, 17, 203, 0.5);
  }
`;

const ButtonInput = styled.input`
  display: inline-block;
  width: 100%;
  padding: 15px;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  border: none;
  border-radius: 8px;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
  text-align: center;

  :hover {
    background: linear-gradient(135deg, #2575fc 0%, #6a11cb 100%);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  }
`;

const SubmitWrapper = styled.div`
  margin-top: 20px;
`;
